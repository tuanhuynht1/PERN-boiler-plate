import React from 'react';

function App() {
  return (
    <h1>PERN STACK BOILER PLATE</h1>
  );
}

export default App;
